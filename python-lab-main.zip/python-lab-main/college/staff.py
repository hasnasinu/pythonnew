def staff():
    print("total no.of staffs are 250")
    
