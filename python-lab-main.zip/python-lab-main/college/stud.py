def stud():
    print("the total no. off students are 1000")
    
