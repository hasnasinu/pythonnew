from Mainpackage.sub1.add import addition
from Mainpackage.sub2.sub import subtraction
a=50
b=40
print("sum of the no.s are =",addition(a,b))
print("difference of the no.s are =",subtraction(a,b))
