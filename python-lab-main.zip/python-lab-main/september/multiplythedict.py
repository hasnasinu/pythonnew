print("multiply the items in a dictionary")
p=dict(A=10,B=3,C=2)
total=1
for i in p:
    total=total*p[i]
print(total)    








