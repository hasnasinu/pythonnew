print("the area of circle")
r=float(input("enter the radius of the circle:"))
print("area of the circle=",3.14*r*r)
