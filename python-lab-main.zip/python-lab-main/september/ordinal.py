print("ORDINAL VALUES OF A WORD")
word=input("enter the word:")
value=[ord(ch) for ch in word]
print("ordinal values:",value)
