print("extension of the file")
filename = input("Enter file name: ")
extension= filename.split(".")[-1]
print("the extension of the file:",extension)
