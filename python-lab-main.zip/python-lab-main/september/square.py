print("SQUARE OF N NUMBERS")
num=int(input("enter the limit:"))
i=1
while(i<num):
    print(i,"*",i,"=",i*i)
    i=i+1
    if(i==num):
     break
     

     
