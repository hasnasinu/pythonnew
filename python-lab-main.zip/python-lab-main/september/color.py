print("list of colors separated by comma")
color=["red","yellow","blue","orange"]
print(color[1])
print(color[-1])   






            
