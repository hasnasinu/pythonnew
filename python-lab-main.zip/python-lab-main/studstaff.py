from college import stud
from college import staff
stud.stud()
res=staff.staff()
print(res)
