print("POSITIVE ,NEGATIVE OR ZERO\n")
num=int(input("enter the number:"))
if num>0:
    print("it is a positive number")
elif num<0:
    print("it is a negative number")
else:
    print("it is zero")
    
    
