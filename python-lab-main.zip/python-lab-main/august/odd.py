print("EVEN OR ODD")
num=int(input("enter the number:\n"))
if num%2==0:
    print("it is an even number")
else:
    print("it is an odd number")
    
