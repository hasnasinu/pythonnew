print("mark\n")
mark=int(input("enter the mark:"))
if mark>=40:
    print("you are passed")
else:
    print("you are failed")

