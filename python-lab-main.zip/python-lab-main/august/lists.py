print("the length of the list")
list=[3,1,4,9,8,2,6]
print(len(list))
print("last item of the list")
print(list[6])
print("list in reverse")
print(list[-1])
print("check if 9 is in the list")
if 9  in  list:
    print("yes 9 is in the list")
print("add 7 to the end of the list")
list.insert(7,7)
print(list)

