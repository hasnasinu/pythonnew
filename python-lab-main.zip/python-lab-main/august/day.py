print("DAYS OF THE WEEK")
day=int(input("enter the number corrosponding to the week:\n"))
if day==1:
        print("monday")
elif day==2:
        print("tuesday")
elif day==3:
        print("wednesday")
elif day==4:
        print("thursday")
elif day==5:
        print("friday")
elif day==6:
        print("saturday")
elif day==7:
        print("sunday")
else:
        print("it is invalid")
               
                
                
