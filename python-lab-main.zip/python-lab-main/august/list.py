list=["apple","banana","orange"]
print(list)
print(len(list))
list1=["abc",123,"true","female"]
print(list1)
print(list[2])
print(list[1:3])
fruits=["apple","banana","orange"]
if "apple" in fruits:
     print("yes apple is in the list")
fruits[1]="blueberry"
print(fruits)
fruits.insert(2,"watermelon")
print(fruits)
fruits.remove("banana")
fruits.pop
print(fruits[-1])
list=["a","b","c"]
for b in list:
    print(b)
for i in range(len(list)):
    print(list[i])
string=input("enter elements")
lst=string.split()
print("the list is",lst)
n=int(input("enter the size of list"))      
print(lst)
