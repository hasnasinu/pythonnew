print("GREATEST OF THREE NUMBERS")

a=int(input("enter the first no:\n"))
b=int(input("enter the second no:\n"))
c=int(input("enter the third no:\n"))
if a>b & a>c:
    print(a,"is greater")
elif b>c:
    print(b,"is greater")
else:
    print(c,"is greater")

      
      
