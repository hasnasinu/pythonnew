def rectangle
a=float(input("enter the length:\n")
b=float(input("enter the breadth:\n")
area=a*b

def circle
r=float(input("enter the radius of the circle:"))
print("area of the circle=",3.14*r*r)        
