print("count the occurence of 'a' in a text")
names = input("Enter the names:\n")
count = names.count('a')
print("Number of times 'a' appears:", count)

