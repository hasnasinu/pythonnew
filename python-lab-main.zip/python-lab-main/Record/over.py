print("replace integers greater than 100 over")
c=[250,960,5,6,8,]
for i in c:
     if i>100:
        print("over")
     else:
         print(i)
