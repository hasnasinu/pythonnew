print("repeated character replaced with $")
word=input("enter the word:\n")
text=word[0]
result=text+word[1:].replace(text,'$')
print(result)


    
    
      
