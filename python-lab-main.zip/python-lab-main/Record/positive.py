print("POSITIVE NUMBERS")
list=[25,1,-3,4,-2,30]
print(list)
for i in list:
 if i>=0:
   print(i)
