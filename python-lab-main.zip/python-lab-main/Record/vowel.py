print("VOWELS FROM A WORD")
word=input("enter the word:")
vowel=["a","e","i","o","u","A","E","I","O","U"]
for char in word:
    if char in vowel:
     print(char)
