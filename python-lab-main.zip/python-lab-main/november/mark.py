class mark:
    totalmark=0
stud1=mark()
stud2=mark()
stud1.totalmark=50
stud2.totalmark=60
print("mark of student 1=",stud1.totalmark)
print("mark of student 2=",stud2.totalmark)


