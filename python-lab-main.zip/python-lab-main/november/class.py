class myclass:
    x=5
print(myclass)
print(myclass.x)
