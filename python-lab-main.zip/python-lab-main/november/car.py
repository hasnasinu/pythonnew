class car:
    def start_engine(self):
        print("Engine started!")
mycar=car()
mycar.start_engine()
