from MyPackage import mod1
from MyPackage import mod2
mod1.gfg()
res=mod2.sum(1,2)
print(res)
